# Good'AI Design System — Project Direction

This project has ONE canonical design system: **brutalist Good'ai**. Older drafts
(a teal/warm-cream "bright pivot", and a black+orange+cool-paper phase) are **dead**
but still contaminate some files. The job is to make every file match the canonical
system below. `colors_and_type.css` is the source of truth for tokens.

## Canonical visual system

**Palette — the five core colours (this is the real one, matches the MUSE-PRO reference):**
- Navy `#202C59` — dark surfaces, headlines, dark card fills, links
- Black `#111111` (`--ink`) — text, borders, hard edges
- Cream `#FFF0D0` (`--paper`) — page canvas. **WARM cream — yes warm this time.**
- Mustard-gold `#F3A62A` (`--gold`) — coloured panels / blocks / sticker labels
- Coral-red `#F4442E` (`--red`) — primary CTA / shout accent

Deeper steps: `--gold-deep #D98E1C`, `--red-deep #D8331F`, `--navy-deep #161E3D`,
`--paper-deep #F6E2B8`. Success `#2E6E3E`, Error `#D8331F`.

**Legacy token aliases** (kept so old files don't break): `--orange*` now maps to the
reds, `--ocean*` maps to the navies, `--hi-yellow` maps to gold. Prefer the new
`--gold / --red / --navy` names in new work.

**Type:** Fraunces (display), DM Sans (sans/UI), JetBrains Mono (mono/eyebrows).
- Italic + WONK on Fraunces = emphasis lift. **One phrase per surface.**

**Shape:** sharp corners (0–8px) on cards & buttons. Pills (999px) ONLY for chips,
status dots, counters. No pill buttons.

**Shadow:** flat offset "stamp" shadows only (e.g. `3px 3px 0 var(--ink)`,
red stamp for CTAs, navy stamp for blocks). **Never blurred shadows.**

**Wordmark:** `Good'ai` — lowercase `ai`, red apostrophe. Never GoodAI / Good AI / goodai.

**Voice:** switched-on Aussie mate. Say automation/system/workflow. Never "AI",
"machine learning", "leverage", "synergy", "optimize", "streamline".

## THE KEY PRINCIPLE (this is what the whole last session was about)

**Paper background, high-contrast COLOURED cards, white-on-colour text.**

White cards on a cream/paper page read as "an unfinished draft you forgot to colour in."
So:
- Default card/section surfaces **carry colour** — navy, gold, red, or black fills
  with cream/white (or black-on-gold) text.
- Cream / paper-raised is the RARE quiet exception, never the default.
- Keep brand restraint by applying it per block: one accent moment inside each
  coloured surface (usually the red CTA).
- The page background stays warm cream — do NOT colour the whole background; colour
  the CARDS and blocks.

## Files that still need fixing (the drift)

- `README.md` — still documents the OLD teal/warm-cream/sunshine system with rounded
  14px corners. **Rewrite** to the canonical brutalist system + the coloured-card principle.
- `preview/colors-teal.html` — DELETE. Teal is not in the system.
- `preview/colors-warm.html` — uses dead `--tomato-*` / `--sun-*` tokens. Rebuild as
  the orange + yellow scales, or remove.
- `preview/components-chat.html` — tomato/teal bubbles, rounded 18px. Rebuild brutalist
  with coloured surfaces.
- `preview/brand-iconography.html` — has "sun"/"tomato" shape states. Convert to
  navy/gold/red/black.
- `preview/spacing-radius.html` — stars 14px "md" as the default radius (rounded-first).
  Re-base so sharp (0–8px) is the default; pills are the labelled exception.
- `preview/spacing-shadow.html` — white tiles + 14px radius. Convert to stamp shadows,
  sharp corners.
- Audit every other `preview/*.html` and `ui_kits/web/*` against `colors_and_type.css`
  and the coloured-card principle; fix any white-on-white surfaces.
- `colors_and_type.css` — confirm it's the single source of truth; remove/alias any
  dead token names the preview files reference.

## What "exports" (must end up consistent)

- `Good'ai Brutalist Skill.html` (+ `Goodai Brutalist Skill (standalone).html`,
  `export/…`) — the rendered source-of-truth doc. Logo currently replaced with a
  "YOUR LOGO" placeholder slot (user supplies their own).
- `ui_kits/web/` — the deployed landing. Already converted: paper bg, ink intake card,
  orange CTA, ocean answer panel, coloured feature strip, g-mark logo removed.

## Settled decisions from the last session
- Canonical = brutalist with the **MUSE-PRO palette**: navy / black / cream / gold / red.
- Cream canvas is WARM (`#FFF0D0`) — the earlier "cool off-white, no warm cream" rule is dead.
- Token file keeps legacy names (`--orange*`→red, `--ocean*`→navy, `--hi-yellow`→gold) as
  aliases so nothing breaks; prefer `--gold/--red/--navy` in new work.
- Corners = sharp; pills only for chips/status.
- Cards = high-contrast coloured, white/cream-on-colour. No white-on-white.
- Logo = removed from landing hero; placeholder slot in the skill doc. User supplies own.
- Background stays warm cream — colour the cards, not the whole background.
